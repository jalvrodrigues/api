import { useEffect, useState } from 'react'
import './App.css'
import Card from './components/card/index'
import AppRoutes from'./routes'

function App() {
   return (
     <AppRoutes />
   )
}

export default App
