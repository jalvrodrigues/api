import styles from './Card.module.css'


function Card({key, nome, img, prec, temp, dim}) { //variaveis podem ser diferentes, mas por boa pratica utilizamos o mesmo nome dos atributos da api



    return (
        <section className={styles.card}>
            <h2  className={styles.nome}>{nome}</h2>
            <img src={img} className={styles.img}></img>
            <div></div>
            <div className={styles.txtmenor}>
                <h3>Precipitação: {prec}</h3>
                <h3>Temperatura: {temp}</h3>
                <h3>Dimensão: {dim}</h3>
            </div>
        </section>
    )
}

export default Card

