import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Filtros from './pages/Filtros'
import Pesquisa from './pages/Pesquisa'
import PageBase from './pages/PageBase'

function AppRoutes() {
    return (
        <>
        <BrowserRouter>
                <Routes>
                        <Route path='/' element={ <PageBase /> }></Route>
                        <Route path="/Home" element={ <Home /> }></Route>
                        <Route path="/Filtros" element={ <Filtros />}></Route>
                        <Route path="/Pesquisa" element={ <Pesquisa />}></Route>
                    
                </Routes>
        </BrowserRouter>
        </>
    )
}

export default AppRoutes
