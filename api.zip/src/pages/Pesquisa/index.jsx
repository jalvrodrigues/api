import { useEffect, useState } from 'react'
import Card from '../../components/Card'
import styles from './Pesquisa.module.css'
import AppRoutes from'../../routes'

function Pesquisa () {

    return (
        <>

        </>
    )
}

export default Pesquisa