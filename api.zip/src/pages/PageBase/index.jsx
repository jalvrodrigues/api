import styles from './PageBase.module.css'
import AppRoutes from'../../routes'
import { Link } from 'react-router-dom'


function PageBase() {
    return (
        <>
         <h1 className={styles.title}>API DE BIOMAS</h1>
         <h2 className={styles.subtitle}>do Minecraft</h2>
         <Link to="/Home" className={styles.start}>START</Link>
            
         
        </>
    )
}

export default PageBase