
import { useEffect, useState } from 'react'
import styles from './Home.module.css'
import Card from '../../components/card/index'
import AppRoutes from'../../routes'
import { Link } from  'react-router-dom'


const Home = () => {
    const [biomas, setBiomas] = useState([]) //useState para receber o conteúdo da api, api tem formato de array []

  useEffect(() => { //useEffect faz acesso a api e retorna
    const buscarBiomas = async () => { //async para procesar a api depois da página toda e não ao mesmo tempo
      const response = await fetch(`https://raw.githubusercontent.com/jalvrodrigues/api/main/biomas.json`) 
      const data = await response.json()
      setBiomas(data) //coloca o valor da api dentro da várivel biomas
    }
    buscarBiomas()
  }, [])

  return (
    <>
      <section >
        <header>
        <Link to="/" className={styles.voltar}>Voltar</Link>
        <h2 id="biomas">Biomas</h2>
        </header>
          <Link to="/Home" className={styles.links}>Home</Link>
          <Link to="/Filtros" className={styles.links}>Filtros</Link>
          <Link to="/Pesquisa" className={styles.links}>Pesquisa</Link>
       
       
        {
          biomas.length > 0 ? (
            <section >
              {
                biomas.map((bio) => ( //faz o map da api e faz repetidamente até o fim da api

                  //passa parâmetros para o card com os valores da api
                  <Card
                      key={bio.id}              
                      nome={bio.nome}
                      img={bio.img}
                      prec={bio.precipitacao}
                      temp={bio.temperatura}
                      dim={bio.dimensao}
                  />
              ))
              }
              </section>
          ) : (
              <p>Carregando biomas...</p>
          )
        }
      </section>
    </>
  )
}

export default Home