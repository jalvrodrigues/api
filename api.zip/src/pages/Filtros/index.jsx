import { useEffect, useState } from 'react'
import Card from '../../components/Card'
import styles from './Filtros.module.css'
import AppRoutes from'../../routes'
import { Link } from 'react-router-dom'

function Filtros () {
    const [biomas, setBiomas] = useState([]) //useState para receber o conteúdo da api, api tem formato de array []

    useEffect(() => { //useEffect faz acesso a api e retorna
      const buscarBiomas = async () => { //async para procesar a api depois da página toda e não ao mesmo tempo
        const response = await fetch(`https://raw.githubusercontent.com/jalvrodrigues/api/main/biomas.json`) 
        const data = await response.json()
        setBiomas(data) //coloca o valor da api dentro da várivel biomas
      }
      buscarBiomas()
    }, [])
  
         
            
    return (
        <>
            <header>
            <Link to="/" className={styles.voltar}>Voltar</Link>
            <h2 className={styles.title}>Filtros</h2>
            </header>
            <Link to="/Home" className={styles.links}>Home</Link>
            <Link to="/Filtros" className={styles.links}>Filtros</Link>
            <Link to="/Pesquisa" className={styles.links}>Pesquisa</Link>

            <div className={styles.inputs}>
            
                <p className={styles.prec}>
                    <div className={styles.icon_prec}>
                        <span class="material-symbols-outlined" > cloud </span>
                    </div> 
                 Selecione a precipitação: </p>

                <select id='sele1' className={styles.filtro_prec}>
                    <option value="selecione">Selecione</option>
                    <option value="chuva">Chuva</option>
                    <option value="neve">Neve</option>
                    <option value="null">Nenhuma</option>
                </select>

                <p className={styles.temp}>
                    <div className={styles.icon_temp}>
                        <span class="material-symbols-outlined" > thermostat </span>
                    </div> 
                Selecione a temperatura: </p>
                
                <select className={styles.filtro_temp}>
                    <option value="selecione">Selecione</option>
                    <option value="Frio">Frio</option>
                    <option value="Ameno">Ameno</option>
                    <option value="quente">Quente</option>
                </select>

                <p className={styles.dim}>
                    <div className={styles.icon_dim}>
                        <span class="material-symbols-outlined" > globe </span>
                    </div> 
                Selecione a dimensão: </p>

                <select className={styles.filtro_dim}>
                    <option value="selecione">Selecione</option>
                    <option value="Overworld">Overworld</option>
                    <option value="Nether">Nether</option>
                    <option value="Fim">Fim</option>
                </select>

            </div>
            
                
             
             {
             biomas.length > 0 ? (
                 <section >
                 {
                   biomas.map((bio) => ( //faz o map da api e faz repetidamente até o fim da api
                     //passa parâmetros para o card com os valores da api
                     
                     <Card
                         key={bio.id}                           
                         nome={bio.nome}
                         img={bio.img}
                         prec={bio.precipitacao}
                         temp={bio.temperatura}
                         dim={bio.dimensao}
                     />
                 ))
                 }
                 </section>
             ) : (
                 <p>Carregando biomas...</p>
             )
       }
     
        </>
    )
}

export default Filtros